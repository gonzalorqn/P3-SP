<?php
require_once "Usuario.php";
require_once "AccesoDatos.php";
class Auto
{
  #ATRIBUTOS

  public $id;//autoincremental
  public $color;
  public $marca;
  public $precio;
  public $modelo;


  #CONSTRUCTOR

  public function __construct($id=null,$color=null,$marca=null,$precio=null,$modelo=null)
  {
      $this->id=$id;
      $this->color=$color;
      $this->marca=$marca;
      $this->precio=$precio;
      $this->modelo=$modelo;
      
  }

  #Metodos Apis

  /*Alta con VALIDACIONES directo en la API*/
  public static function Alta($request,$response,$next)
  {
    //json de auto
    $ArrayDeParametros = $request->getParsedBody();
    $auto = json_decode($ArrayDeParametros['json']);

    //json de retorno
    $objJson = new stdClass();
    $objJson->Exito = false;
    $objJson->Mensaje = "Error no se pudo agregar el auto en la BD";

    $autoObj = new Auto(10,$auto->color,$auto->marca,$auto->precio,$auto->modelo);

    if($autoObj->AltaAutoBd())
    {
        $objJson->Exito = true;
        $objJson->Mensaje = "Se pudo agregar el auto en la BD";
        $newResponse = $response->withJson($objJson,200);

    }
    else
    {
        $newResponse = $response->withJson($objJson,418);
    }

   return $newResponse;

  }
  
  /*Alta sin VALIDACIONES sobre la API*/
  /*public static function Alta($request,$response,$next)
  {
    //json de media
    $ArrayDeParametros = $request->getParsedBody();
    $media=json_decode ($ArrayDeParametros['media']);

    //json de retorno
    $objJson= new stdClass();
    $objJson->Exito=true;
    $objJson->Mensaje="Se agrego la media";

    $mediaObj = new Media($media->id,$media->color,$media->marca,$media->precio,$media->talle);

    $mediaObj->AltaMediaBd();


   //return $response->withJson($objJson,200);
   return $response->getBody()->write("Se ha insertado la media.");

  }*/


  /*TraerTodos con VALIDACIONES directo en la API*/
  public static function TraerTodos($request,$response,$next)
  {
    $objJson = new stdClass();
    $objJson->Exito = false;
    $objJson->Mensaje = "Error no se pudo recuperar todos los autos!";
    $objJson->tabla = "";

    $auto = new Auto();
    $arrayAutos = $auto->TraerTodosLosAutosBD();

    if(count($arrayAutos)>0)
    {
        $objJson->Exito = true;
        $objJson->Mensaje = "Se recuperaron todos los autos";
        $objJson->tabla .= `<table border=5><tr><td>ID</td><td>COLOR</td><td>MARCA</td><td>PRECIO</td><td>MODELO</td></tr>`;

        foreach($arrayAutos as $autito)
        {
          $objJson->tabla .= "<tr><td>".$autito->id."</td><td>".$autito->color."</td><td>".$autito->marca."</td><td>".$autito->precio."</td><td>".$autito->modelo."</td></tr>";
        }
        $objJson->tabla .= "</table>";
        $newResponse = $response->withJson($objJson,200);
    }
    else
    {
       $newResponse = $response->withJson($objJson,424);
    }

   return $newResponse;
  }
  

  /*TraerTodos sin VALIDACIONES sobre la API*/
  /*public static function TraerTodos($request,$response,$next)
  {
    $objJson= new stdClass();

    $media = new Media();
    $arrayMedias=$media->TraerTodasLasMediasBD();

    $objJson->Exito=true;
    $objJson->Mensaje="Se recuperaron todos las medias";
    $objJson->arrayJson=$arrayMedias;

  // return $response->withJson($objJson,200);
   return $response->withJson($arrayMedias,200);
  }*/

  public static function Borrar($request,$response,$next)
  {
    $ArrayDeParametros = $request->getParsedBody();

    $id_media=$ArrayDeParametros['id_media'];

  
    $media= new Media($id_media);

    $objJson= new stdClass();
    $objJson->Exito=false;
    $objJson->Mensaje="No se pudo borrar la media";

    $cantidadDeBorrados= $media->BorrarMediaBD();
    if($cantidadDeBorrados>0)
    {
      $objJson->Exito=true;
      $objJson->Mensaje="Se pudo borrar la media";

      $newResponse=$response->withJson($objJson,200);
    }
    else
    {
      $newResponse=$response->withJson($objJson,404);
    }

    return $newResponse;
  }

  public static function Modificar($request,$response,$next)
  {
    //json de media
    $ArrayDeParametros = $request->getParsedBody();
    $media=json_decode ($ArrayDeParametros['media']);
    

    //json de retorno
    $objJson= new stdClass();
    $objJson->Exito=false;
    $objJson->Mensaje="Error no se pudo modificar la media en la BD";

    $mediaObj = new Media($media->id,$media->color,$media->marca,$media->precio,$media->talle);


    if($mediaObj->ModificarMediaBD())
    {
        $objJson->Exito=true;
        $objJson->Mensaje="Se pudo modifcar la media en la BD";
        $newResponse=$response->withJson($objJson,200);

    }
    else
    {
        $newResponse = $response->withJson($objJson,404);
    }

   return $newResponse;

  }



  #Metodos Base de Datos
  
  private function AltaAutoBd()
  {
    $objetoAccesoDato = AccesoDatos::DameUnObjetoAcceso(); 
    $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into autos (color,marca,precio,modelo)values(:color, :marca, :precio, :modelo)");

    // return $objetoAccesoDato->RetornarUltimoIdInsertado();
    $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
    $consulta->bindValue(':marca', $this->marca, PDO::PARAM_STR);
    $consulta->bindValue(':precio', $this->precio, PDO::PARAM_INT);
    $consulta->bindValue(':modelo', $this->modelo, PDO::PARAM_STR);

    return $consulta->execute();
  }

  private function TraerTodosLosAutosBD()
  {
    $autos = array();
    $objetoDatos = AccesoDatos::DameUnObjetoAcceso();
    $consulta = $objetoDatos->RetornarConsulta('SELECT * FROM autos'); //Se prepara la consulta, aquí se podrían poner los alias
    $consulta->execute();

    while($fila = $consulta->fetch())
    {
      $auto = new Auto($fila[0],$fila[1],$fila[2],$fila[3],$fila[4]);
      array_push($autos,$auto);
    }
    return $autos;
  }

  private function BorrarMediaBD()
  {
    $objetoAccesoDato = AccesoDatos::DameUnObjetoAcceso(); 
    $consulta =$objetoAccesoDato->RetornarConsulta("
    DELETE 
    FROM medias 				
    WHERE id=:id");	
    $consulta->bindValue(':id',$this->id, PDO::PARAM_INT);		
    $consulta->execute();
    return $consulta->rowCount();
  }

  private function ModificarMediaBD()
  {
    $objetoDatos = AccesoDatos::DameUnObjetoAcceso();

    //ejecuto la consulta de eliminar un usuario en el "legajo" especificado en la base de datos
    $consulta =$objetoDatos->RetornarConsulta('UPDATE medias SET color = :color, marca = :marca, precio = :precio, talle = :talle WHERE id = :idAUX' );

    $consulta->bindValue(':color', $this->color, PDO::PARAM_STR);
    $consulta->bindValue(':marca', $this->marca, PDO::PARAM_STR);
    $consulta->bindValue(':precio', $this->precio, PDO::PARAM_INT);
    $consulta->bindValue(':talle', $this->talle, PDO::PARAM_STR);

    $consulta->bindValue(':idAUX', $this->id, PDO::PARAM_INT);

    return $consulta->execute();
  }

}

?>
<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Firebase\JWT\JWT;

require_once './vendor/autoload.php';

require_once './BACKEND/clases/AccesoDatos.php';
require_once './BACKEND/clases/Auto.php';
require_once './BACKEND/clases/Login.php';
require_once './BACKEND/clases/Usuario.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

#AUTOS

$app->post('[/]', \Auto::class . '::Alta');
$app->get('/autos',\Auto::class . '::TraerTodos');
//$app->delete('[/]',\Media::class . '::Borrar')->add(\MW::class . '::MWVerificarPropietario')->add(\MW::class . ':VerificarToken');
//$app->put('[/]',\Media::class . '::Modificar')->add(\MW::class . '::MWVerificarEncargado')->add(\MW::class . ':VerificarToken');

#USUARIOS

//$app->post('/usuarios', \Usuario::class . '::Alta')->add(\MW::class . ':VerificarBDCorreoYClave')->add(\MW::class . '::VerificarVacioCorreoYClave')->add(\MW::class . ':VerificarSetCorreoYClave');
$app->post('/usuarios', \Usuario::class . '::Alta');
$app->get('[/]',\Usuario::class . '::TraerTodos');

#Login

$app->post('/login', \Login::class . '::LoginIngreso');
//->add(\MW::class . ':VerificarBDCorreoYClave')->add(\MW::class . '::VerificarVacioCorreoYClave')->add(\MW::class . ':VerificarSetCorreoYClave');
$app->get('/login', \Login::class . '::VerificarJWTLogin');

#Listado
/*
$app->group('/listados', function () {
  $this->get('/medias',\Media::class . '::TraerTodos');
});*/

$app->run();